/*
# TaxiRoute SA — Full Schema and Seed Data

## Overview
Creates the complete database for TaxiRoute SA, a South African minibus taxi route and published-fare finder.

## Tables
1. `associations` — Taxi associations (JMTTA, TATA, JVTA)
2. `taxi_ranks` — Physical taxi rank locations
3. `routes` — Minibus taxi routes (origin → destination), 30 routes
4. `fare_history` — Published fare records, one per route
5. `community_reports` — Commuter-submitted reports (always start as pending)

## Security (RLS)
- This is a NO-AUTH public app (no login required).
- Public (anon) can READ associations, taxi_ranks, active routes, published fares.
- Public (anon) can INSERT community_reports (always pending).
- No public UPDATE/DELETE on any official data.
- Community reports can never modify official routes or fares.

## Seed Data
- 3 associations: JMTTA, TATA, JVTA
- 30 taxi ranks (unique origin/destination locations)
- 30 active routes with exact codes, origins, destinations, fares
- 30 fare_history records (one published fare per route)
*/

-- ============================================================
-- TABLE: associations
-- ============================================================
CREATE TABLE IF NOT EXISTS associations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT UNIQUE NOT NULL,
  contact_phone TEXT NULL,
  contact_email TEXT NULL,
  notes TEXT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE associations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_associations" ON associations;
CREATE POLICY "public_read_associations" ON associations FOR SELECT
  TO anon, authenticated USING (true);

-- ============================================================
-- TABLE: taxi_ranks
-- ============================================================
CREATE TABLE IF NOT EXISTS taxi_ranks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT UNIQUE NOT NULL,
  suburb TEXT NULL,
  city TEXT NULL,
  province TEXT DEFAULT 'Gauteng',
  latitude NUMERIC NULL,
  longitude NUMERIC NULL,
  notes TEXT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE taxi_ranks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_taxi_ranks" ON taxi_ranks;
CREATE POLICY "public_read_taxi_ranks" ON taxi_ranks FOR SELECT
  TO anon, authenticated USING (true);

-- ============================================================
-- TABLE: routes
-- ============================================================
CREATE TABLE IF NOT EXISTS routes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_code TEXT UNIQUE NOT NULL,
  association_id UUID REFERENCES associations(id),
  origin_name TEXT NOT NULL,
  destination_name TEXT NOT NULL,
  origin_rank_id UUID REFERENCES taxi_ranks(id),
  destination_rank_id UUID REFERENCES taxi_ranks(id),
  route_description TEXT NULL,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE routes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_active_routes" ON routes;
CREATE POLICY "public_read_active_routes" ON routes FOR SELECT
  TO anon, authenticated USING (active = true);

-- ============================================================
-- TABLE: fare_history
-- ============================================================
CREATE TABLE IF NOT EXISTS fare_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id UUID REFERENCES routes(id) ON DELETE CASCADE,
  fare_zar NUMERIC(10,2) NOT NULL,
  currency TEXT DEFAULT 'ZAR',
  effective_date DATE NOT NULL,
  verification_date DATE DEFAULT CURRENT_DATE,
  source TEXT NULL,
  source_type TEXT DEFAULT 'published_notice',
  status TEXT DEFAULT 'published',
  notes TEXT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE fare_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_published_fares" ON fare_history;
CREATE POLICY "public_read_published_fares" ON fare_history FOR SELECT
  TO anon, authenticated USING (status = 'published');

-- ============================================================
-- TABLE: community_reports
-- ============================================================
CREATE TABLE IF NOT EXISTS community_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id UUID NULL REFERENCES routes(id),
  reported_fare NUMERIC(10,2) NULL,
  report_type TEXT NOT NULL,
  description TEXT NOT NULL,
  submitted_at TIMESTAMPTZ DEFAULT now(),
  status TEXT DEFAULT 'pending'
);

ALTER TABLE community_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_insert_community_reports" ON community_reports;
CREATE POLICY "public_insert_community_reports" ON community_reports FOR INSERT
  TO anon, authenticated WITH CHECK (status = 'pending');

DROP POLICY IF EXISTS "public_read_own_community_reports" ON community_reports;
CREATE POLICY "public_read_own_community_reports" ON community_reports FOR SELECT
  TO anon, authenticated USING (true);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_routes_origin_lower ON routes (lower(trim(origin_name)));
CREATE INDEX IF NOT EXISTS idx_routes_dest_lower ON routes (lower(trim(destination_name)));
CREATE INDEX IF NOT EXISTS idx_routes_active ON routes (active);
CREATE INDEX IF NOT EXISTS idx_fare_history_route_id ON fare_history (route_id);
CREATE INDEX IF NOT EXISTS idx_fare_history_effective_date ON fare_history (effective_date);

-- ============================================================
-- SEED: ASSOCIATIONS
-- ============================================================
INSERT INTO associations (name, notes) VALUES
  ('JMTTA', 'Johannesburg Metropolitan Taxi Association'),
  ('TATA', 'Tembisa Taxi Association'),
  ('JVTA', 'Johannesburg/Vosloorus Taxi Association')
ON CONFLICT (name) DO NOTHING;

-- ============================================================
-- SEED: TAXI RANKS
-- ============================================================
INSERT INTO taxi_ranks (name, province) VALUES
  ('Esangweni Taxi Rank (Sangweni)', 'Gauteng'),
  ('Gateway Shopping Centre (Midrand)', 'Gauteng'),
  ('Midrand Taxi Rank', 'Gauteng'),
  ('Waterfall City', 'Gauteng'),
  ('Midstream', 'Gauteng'),
  ('Centurion Taxi Rank', 'Gauteng'),
  ('Shoprite', 'Gauteng'),
  ('Vodaworld', 'Gauteng'),
  ('Pretoria Station', 'Gauteng'),
  ('Samrand Road', 'Gauteng'),
  ('Olievenhoutbosch Taxi Rank', 'Gauteng'),
  ('Tembisa Main Taxi Rank', 'Gauteng'),
  ('Alexandra Taxi Rank', 'Gauteng'),
  ('Kyalami Corner Shopping Centre', 'Gauteng'),
  ('Linbro Park', 'Gauteng'),
  ('Sandton City Taxi Rank', 'Gauteng'),
  ('Sunninghill Taxi Rank', 'Gauteng'),
  ('Rivonia / Klipfontein View', 'Gauteng'),
  ('Randburg Taxi Rank', 'Gauteng'),
  ('Fourways Crossing Taxi Rank', 'Gauteng'),
  ('Waterfall City (Mall of Africa)', 'Gauteng'),
  ('Diepsloot Taxi Rank', 'Gauteng'),
  ('Johannesburg CBD', 'Gauteng'),
  ('Roodekop Ext 31', 'Gauteng'),
  ('Rondebult / Leondale / Buhle Park', 'Gauteng'),
  ('Spruitview / Phumula', 'Gauteng'),
  ('East Rand Mall / Boksburg Taxi Rank', 'Gauteng'),
  ('Graceland (Elspark)', 'Gauteng'),
  ('Vosloorus Taxi Rank', 'Gauteng'),
  ('Pretoria CBD / Bosman', 'Gauteng')
ON CONFLICT (name) DO NOTHING;

-- ============================================================
-- SEED: ROUTES + FARES
-- Uses a helper function to insert route + fare in one step.
-- ============================================================
CREATE OR REPLACE FUNCTION seed_route(
  p_code TEXT,
  p_assoc TEXT,
  p_origin TEXT,
  p_dest TEXT,
  p_fare NUMERIC,
  p_effective DATE,
  p_verification DATE
) RETURNS VOID AS $$
DECLARE
  v_assoc_id UUID;
  v_origin_rank UUID;
  v_dest_rank UUID;
  v_route_id UUID;
BEGIN
  SELECT id INTO v_assoc_id FROM associations WHERE name = p_assoc;
  SELECT id INTO v_origin_rank FROM taxi_ranks WHERE name = p_origin;
  SELECT id INTO v_dest_rank FROM taxi_ranks WHERE name = p_dest;

  INSERT INTO routes (route_code, association_id, origin_name, destination_name, origin_rank_id, destination_rank_id, active)
  VALUES (p_code, v_assoc_id, p_origin, p_dest, v_origin_rank, v_dest_rank, true)
  ON CONFLICT (route_code) DO NOTHING
  RETURNING id INTO v_route_id;

  IF v_route_id IS NULL THEN
    SELECT id INTO v_route_id FROM routes WHERE route_code = p_code;
  END IF;

  INSERT INTO fare_history (route_id, fare_zar, currency, effective_date, verification_date, source, source_type, status)
  VALUES (v_route_id, p_fare, 'ZAR', p_effective, p_verification, 'Taxi association published fare notice – TaxiRoute SA starter dataset', 'published_notice', 'published')
  ON CONFLICT DO NOTHING;
END;
$$ LANGUAGE plpgsql;

-- JMTTA routes (effective 2026-05-11, verification 2026-05-11)
SELECT seed_route('JMTTA-001', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Gateway Shopping Centre (Midrand)', 26.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-002', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Midrand Taxi Rank', 23.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-003', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Waterfall City', 23.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-004', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Midstream', 28.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-005', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Centurion Taxi Rank', 28.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-006', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Shoprite', 26.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-007', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Vodaworld', 24.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-008', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Pretoria Station', 28.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-009', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Samrand Road', 26.00, '2026-05-11', '2026-05-11');
SELECT seed_route('JMTTA-010', 'JMTTA', 'Esangweni Taxi Rank (Sangweni)', 'Olievenhoutbosch Taxi Rank', 31.00, '2026-05-11', '2026-05-11');

-- TATA routes (effective 2026-05-04, verification 2026-05-04)
SELECT seed_route('TATA-001', 'TATA', 'Tembisa Main Taxi Rank', 'Alexandra Taxi Rank', 26.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-002', 'TATA', 'Tembisa Main Taxi Rank', 'Kyalami Corner Shopping Centre', 24.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-003', 'TATA', 'Tembisa Main Taxi Rank', 'Linbro Park', 24.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-004', 'TATA', 'Tembisa Main Taxi Rank', 'Sandton City Taxi Rank', 27.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-005', 'TATA', 'Tembisa Main Taxi Rank', 'Sunninghill Taxi Rank', 27.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-006', 'TATA', 'Tembisa Main Taxi Rank', 'Rivonia / Klipfontein View', 27.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-007', 'TATA', 'Tembisa Main Taxi Rank', 'Randburg Taxi Rank', 29.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-008', 'TATA', 'Tembisa Main Taxi Rank', 'Fourways Crossing Taxi Rank', 29.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-009', 'TATA', 'Tembisa Main Taxi Rank', 'Waterfall City (Mall of Africa)', 23.00, '2026-05-04', '2026-05-04');
SELECT seed_route('TATA-010', 'TATA', 'Tembisa Main Taxi Rank', 'Diepsloot Taxi Rank', 33.00, '2026-05-04', '2026-05-04');

-- JVTA routes (effective 2026-04-01, verification 2026-04-01)
SELECT seed_route('JVTA-001', 'JVTA', 'Johannesburg CBD', 'Roodekop Ext 31', 24.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-002', 'JVTA', 'Johannesburg CBD', 'Rondebult / Leondale / Buhle Park', 26.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-003', 'JVTA', 'Johannesburg CBD', 'Spruitview / Phumula', 26.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-004', 'JVTA', 'Johannesburg CBD', 'East Rand Mall / Boksburg Taxi Rank', 26.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-005', 'JVTA', 'Johannesburg CBD', 'Graceland (Elspark)', 26.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-006', 'JVTA', 'Vosloorus Taxi Rank', 'Sandton City Taxi Rank', 33.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-007', 'JVTA', 'Vosloorus Taxi Rank', 'Midrand Taxi Rank', 40.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-008', 'JVTA', 'Vosloorus Taxi Rank', 'Centurion Taxi Rank', 45.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-009', 'JVTA', 'Vosloorus Taxi Rank', 'Pretoria CBD / Bosman', 65.00, '2026-04-01', '2026-04-01');
SELECT seed_route('JVTA-010', 'JVTA', 'Johannesburg CBD', 'Vosloorus Taxi Rank', 27.00, '2026-04-01', '2026-04-01');

-- Drop the helper function (no longer needed after seeding)
DROP FUNCTION IF EXISTS seed_route(TEXT, TEXT, TEXT, TEXT, NUMERIC, DATE, DATE);